import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PocNgrxComponent } from './poc-ngrx.component';

describe('PocNgrxComponent', () => {
  let component: PocNgrxComponent;
  let fixture: ComponentFixture<PocNgrxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PocNgrxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PocNgrxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
